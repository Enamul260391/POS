<?php

try {
    $pdo = new PDO('mysql:host=127.0.0.1;port=3306;dbname=pos_database', 'root', '');
    echo 'MySQL CONNECTED OK' . PHP_EOL;
    $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    echo 'Tables count: ' . count($tables) . PHP_EOL;
    echo 'Tables: ' . implode(', ', $tables) . PHP_EOL;
} catch (Exception $e) {
    echo 'MySQL FAILED: ' . $e->getMessage() . PHP_EOL;
}
