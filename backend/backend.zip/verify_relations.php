<?php

require __DIR__ . '/vendor/autoload.php';

$app = require __DIR__ . '/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use App\Models\User;
use App\Models\Business;

echo "=== User Relationships ===" . PHP_EOL;
$u = new User;
foreach (['business','roles','stockMovements','purchases','sales','payments','saleReturns','expenses','cashRegisterTransactions','openedCashRegisters','closedCashRegisters'] as $m) {
    $r = $u->$m();
    echo $m . ' => ' . get_class($r) . PHP_EOL;
}

echo PHP_EOL . "=== Business Relationships ===" . PHP_EOL;
$b = new Business;
foreach (['settings','users','categories','products','customers','suppliers','purchases','sales','payments','stockMovements','saleReturns','expenseCategories','expenses','cashRegisters','cashRegisterTransactions'] as $m) {
    $r = $b->$m();
    echo $m . ' => ' . get_class($r) . PHP_EOL;
}

echo PHP_EOL . "=== Foreign Key Verification ===" . PHP_EOL;

// Verify User foreign keys
echo "User.business: " . $u->business()->getForeignKey() . PHP_EOL;
echo "User.roles pivot: " . implode(',', $u->roles()->getPivotColumns()) . ' | foreignPivot: ' . $u->roles()->getForeignPivotName() . ' relatedPivot: ' . $u->roles()->getRelatedPivotName() . PHP_EOL;

// Verify User relationships foreign keys
echo "User.stockMovements FK: " . $u->stockMovements()->getForeignKey() . PHP_EOL;
echo "User.purchases FK: " . $u->purchases()->getForeignKey() . PHP_EOL;
echo "User.sales FK: " . $u->sales()->getForeignKey() . PHP_EOL;
echo "User.payments FK: " . $u->payments()->getForeignKey() . PHP_EOL;
echo "User.saleReturns FK: " . $u->saleReturns()->getForeignKey() . PHP_EOL;
echo "User.expenses FK: " . $u->expenses()->getForeignKey() . PHP_EOL;
echo "User.cashRegisterTransactions FK: " . $u->cashRegisterTransactions()->getForeignKey() . PHP_EOL;
echo "User.openedCashRegisters FK: " . $u->openedCashRegisters()->getForeignKey() . PHP_EOL;
echo "User.closedCashRegisters FK: " . $u->closedCashRegisters()->getForeignKey() . PHP_EOL;

echo PHP_EOL;
echo "All relationship methods resolve correctly." . PHP_EOL;
