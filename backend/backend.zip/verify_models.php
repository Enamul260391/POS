<?php

require __DIR__ . '/vendor/autoload.php';

$app = require __DIR__ . '/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

$models = [
    App\Models\Business::class,
    App\Models\BusinessSetting::class,
    App\Models\User::class,
    App\Models\Role::class,
    App\Models\Permission::class,
    App\Models\Category::class,
    App\Models\Product::class,
    App\Models\StockMovement::class,
    App\Models\Customer::class,
    App\Models\Supplier::class,
    App\Models\Purchase::class,
    App\Models\PurchaseItem::class,
    App\Models\Sale::class,
    App\Models\SaleItem::class,
    App\Models\Payment::class,
    App\Models\SaleReturn::class,
    App\Models\SaleReturnItem::class,
    App\Models\ExpenseCategory::class,
    App\Models\Expense::class,
    App\Models\CashRegister::class,
    App\Models\CashRegisterTransaction::class,
];

foreach ($models as $model) {
    $instance = new $model;
    echo $model . ' => table: ' . $instance->getTable();
    echo ' | fillable: ' . count($instance->getFillable());
    echo ' | casts: ' . count($instance->getCasts());

    $uses = class_uses($model);
    echo ' | softDeletes: ' . (in_array('Illuminate\Database\Eloquent\SoftDeletes', $uses) ? 'YES' : 'NO');

    $relations = [];
    $methods = get_class_methods($model);
    foreach ($methods as $method) {
        if (in_array($method, ['business', 'users', 'settings', 'roles', 'permissions', 'category', 'product', 'saleItems', 'purchaseItems', 'stockMovements', 'saleReturnItems', 'supplier', 'purchases', 'purchaseItems', 'customer', 'sales', 'saleItems', 'payments', 'saleReturns', 'saleReturnItems', 'creator', 'updater', 'cashier', 'receiver', 'openedBy', 'closedBy', 'transactions', 'cashRegister', 'expenseCategory', 'expenses', 'reference', 'purchase', 'saleItem', 'saleReturn', 'sale', 'purchase'])) {
            try {
                $rel = $instance->$method();
                if ($rel instanceof Illuminate\Database\Eloquent\Relations\Relation) {
                    $relations[] = $method . ':' . get_class($rel);
                }
            } catch (\Throwable $e) {
                $relations[] = $method . ':[ERROR]';
            }
        }
    }

    echo ' | relationships: ' . implode(', ', $relations) . PHP_EOL;
}

echo PHP_EOL . 'All 21 models loaded and verified.' . PHP_EOL;
